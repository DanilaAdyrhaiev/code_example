from flask import Flask
from flask import render_template

app = Flask("app")

@app.route("/<name>")
def home(name):
    return render_template("index.html", name = name)

app.run(debug=True)